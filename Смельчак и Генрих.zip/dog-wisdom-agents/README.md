# 🐕🐕 Dog Wisdom Agents Documentation

Полная документация для ИИ-агентов проекта «Собачья мудрость».

---

## 📁 Файлы

| Файл | Назначение |
|------|------------|
| `Smelchak_Full_Profile.md` | Полный профиль Смельчака — учителя английского |
| `Genrikh_Full_Profile.md` | Полный профиль Генриха — учителя русского |
| `Duo_Teaching_Guide.md` | Руководство по совместному обучению |

---

## 🔗 Субагенты

Субагенты находятся в: `C:\Users\User\.qwen\agents\`

- `smelchak-english-teacher` — субагент Смельчака
- `genrikh-russian-teacher` — субагент Генриха

---

## 📖 Как использовать

### Для копирования в `.qwen/`:

**1. Скопируй эту папку в:**
```
C:\Users\User\.qwen\agents\
```

**2. Субагенты могут читать эти файлы через команду `read_file`:**

**Пример:**
```
Смельчак, прочитай раздел VII из твоего полного профиля
```

**Путь для чтения:**
```
~/.qwen/dog-wisdom-agents/Smelchak_Full_Profile.md
~/.qwen/dog-wisdom-agents/Genrikh_Full_Profile.md
~/.qwen/dog-wisdom-agents/Duo_Teaching_Guide.md
```

---

## 📍 Структура

```
C:\Users\User\.qwen\
├── agents/
│   ├── smelchak-english-teacher.md    ← Субагент (системный промпт)
│   └── genrikh-russian-teacher.md     ← Субагент (системный промпт)
└── dog-wisdom-agents/
    ├── Smelchak_Full_Profile.md       ← Полный профиль
    ├── Genrikh_Full_Profile.md        ← Полный профиль
    ├── Duo_Teaching_Guide.md          ← Руководство
    └── README.md                      ← Этот файл
```

---

## 🎯 Назначение

| Уровень | Файлы | Зачем |
|---------|-------|-------|
| **Субагенты** | `~/.qwen/agents/` | Для работы в любом проекте |
| **Документация** | `~/.qwen/dog-wisdom-agents/` | Для чтения деталей субагентами |

---

## 🔄 Обновление

При изменении полных профилей:
1. Обнови файлы в этой папке
2. Скопируй в `C:\Users\User\.qwen\agents//dog-wisdom-agents\`
3. При необходимости обнови системные промпты субагентов

---

*Проект «Собачья мудрость. Секрет счастья»*
*Последнее обновление: 5 марта 2026 г.*
